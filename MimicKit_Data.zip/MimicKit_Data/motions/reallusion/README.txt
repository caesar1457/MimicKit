This motion data is provided courtesy of Reallusion,
strictly for noncommercial use. The original motion data
is available at:
https://actorcore.reallusion.com/motion/pack/studio-mocap-sword-and-shield-stunts
https://actorcore.reallusion.com/motion/pack/studio-mocap-sword-and-shield-moves
